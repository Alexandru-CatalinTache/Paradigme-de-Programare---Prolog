
vmpoints(Test, Points):-
        member(Test:Points,
               [
               intrebari:1,
               intrebari_nsol:0.2,
               completare:2,
               completare_nsol:0.4%,
               %lungime:1,
               %lungime_nsol:0.2,
               %intersectie:2,
               %intersectie_sols:0.4%,
               %candidates:1,
               %rezolvare:3,
               %stress_test:0.8
               ]).
